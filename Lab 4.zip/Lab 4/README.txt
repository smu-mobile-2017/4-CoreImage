Justin Wilson
Jake Rowland
Paul Herz

If it was 30fps then 100 points equates to 100 frames, meaning 3333 milliseconds of finger-time are represented in the 100 frame average array